BCC-HUB x MNU FinTech Hackathon — агент проверки требований (reqval)

Репозиторий с агентом:  https://github.com/saynzz/reqval-agent
Версия агента:          тег v1.0 (коммит 33249c5)
Модель:                 anthropic/claude-sonnet-5.5 через OpenRouter

Состав пакета:
  requirements.md     — выданный документ требований (без изменений)
  report.md           — отчёт о проверке, сформированный агентом (паспорт, нарезка, проверка каждого
                        требования и набора, сводка, итог)
  report.json         — тот же отчёт в машиночитаемом виде
  report.llm.jsonl    — журнал всех обращений агента к модели; его SHA-256 указан в паспорте отчёта

Повторить прогон (инструкция и получение ключа — в README репозитория):
  git clone https://github.com/saynzz/reqval-agent.git && cd reqval-agent
  python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt
  cp .env.example .env        # вписать OPENROUTER_API_KEY
  python -m reqval docs/requirements.md out/report.md

Итог прогона 27.11.2026 12:10 (Алматы): НЕ ГОТОВ — 59 требований, 64 дефекта (5 критичных),
13 обращений к модели, 132 с, $0.74.
